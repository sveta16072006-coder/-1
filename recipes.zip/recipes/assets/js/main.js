// ============================================
// main.js - основные функции сайта рецептов
// ============================================

document.addEventListener('DOMContentLoaded', function() {
    console.log('Сайт рецептов загружен!');
    
    // 1. Валидация формы входа/регистрации
    initFormValidation();
    
    // 2. Анимация карточек рецептов
    initRecipeCards();
    
    // 3. Подтверждение удаления
    initDeleteConfirm();
    
    // 4. Адаптивное меню (для мобильных)
    initMobileMenu();
});

/**
 * 1. Валидация простых форм
 */
function initFormValidation() {
    const forms = document.querySelectorAll('form');
    
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            let valid = true;
            const inputs = this.querySelectorAll('input[required]');
            
            inputs.forEach(input => {
                if (!input.value.trim()) {
                    valid = false;
                    input.style.borderColor = 'red';
                    
                    // Показываем подсказку
                    if (!input.nextElementSibling || !input.nextElementSibling.classList.contains('error-hint')) {
                        const hint = document.createElement('small');
                        hint.className = 'error-hint';
                        hint.style.color = 'red';
                        hint.textContent = 'Заполните это поле';
                        input.parentNode.appendChild(hint);
                    }
                } else {
                    input.style.borderColor = '';
                    const hint = input.nextElementSibling;
                    if (hint && hint.classList.contains('error-hint')) {
                        hint.remove();
                    }
                }
            });
            
            if (!valid) {
                e.preventDefault();
                alert('Заполните все обязательные поля!');
            }
        });
    });
}

/**
 * 2. Анимации для карточек рецептов
 */
function initRecipeCards() {
    const cards = document.querySelectorAll('.recipe-card, .card, .item');
    
    cards.forEach(card => {
        // Эффект при наведении
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'scale(1.02)';
            this.style.transition = 'transform 0.3s';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'scale(1)';
        });
    });
}

/**
 * 3. Подтверждение важных действий
 */
function initDeleteConfirm() {
    const deleteButtons = document.querySelectorAll('.delete-btn, .btn-danger, a[href*="delete"]');
    
    deleteButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            if (!confirm('Вы уверены, что хотите удалить?')) {
                e.preventDefault();
            }
        });
    });
}

/**
 * 4. Мобильное меню (если есть)
 */
function initMobileMenu() {
    const menuToggle = document.getElementById('menu-toggle');
    const navMenu = document.querySelector('nav');
    
    if (menuToggle && navMenu) {
        menuToggle.addEventListener('click', function() {
            navMenu.classList.toggle('show');
        });
    }
}

/**
 * 5. Простой поиск (опционально)
 */
function initSimpleSearch() {
    const searchInput = document.querySelector('.search-input');
    
    if (searchInput) {
        searchInput.addEventListener('keyup', function() {
            const filter = this.value.toLowerCase();
            const items = document.querySelectorAll('.recipe-item, .card');
            
            items.forEach(item => {
                const text = item.textContent.toLowerCase();
                item.style.display = text.includes(filter) ? '' : 'none';
            });
        });
    }
}

// Автоматическое обновление года в футере
const yearSpan = document.getElementById('current-year');
if (yearSpan) {
    yearSpan.textContent = new Date().getFullYear();
}