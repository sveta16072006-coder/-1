<?php
// functions.php - вспомогательные функции
require_once 'config.php';

function isLoggedIn() {
    return isset($_SESSION['user']) && !empty($_SESSION['user']);
}

function isAdmin() {
    return isLoggedIn() && $_SESSION['user']['role'] === 'admin';
}

function redirect($url) {
    header("Location: " . SITE_URL . $url);
    exit();
}

function escape($data) {
    return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
}

function requireLogin() {
    if (!isLoggedIn()) {
        redirect('pages/auth/login.php');
    }
}

function requireAdmin() {
    requireLogin();
    if (!isAdmin()) {
        redirect('');
    }
}
?>