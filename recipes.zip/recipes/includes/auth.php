<?php
/**
 * auth.php - функции для авторизации и регистрации
 */

// Подключаем конфигурацию и базу данных
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/database.php';

/**
 * Регистрация нового пользователя
 */
function registerUser($username, $email, $password, $full_name = '') {
    $db = Database::connect();
    
    // Проверяем, существует ли пользователь
    $stmt = $db->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
    $stmt->bind_param("ss", $username, $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return ['success' => false, 'error' => 'Пользователь с таким логином или email уже существует'];
    }
    
    // Хешируем пароль
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    // Создаем пользователя
    $stmt = $db->prepare("INSERT INTO users (username, email, password, full_name, role) VALUES (?, ?, ?, ?, 'user')");
    $stmt->bind_param("ssss", $username, $email, $hashed_password, $full_name);
    
    if ($stmt->execute()) {
        // Автоматически авторизуем пользователя после регистрации
        $user_id = $stmt->insert_id;
        loginUser($username, $password);
        
        return ['success' => true, 'user_id' => $user_id];
    } else {
        return ['success' => false, 'error' => 'Ошибка при создании пользователя'];
    }
}

/**
 * Авторизация пользователя
 */
function loginUser($login, $password) {
    $db = Database::connect();
    
    // Ищем пользователя по логину или email
    $stmt = $db->prepare("SELECT id, username, email, password, full_name, role FROM users WHERE username = ? OR email = ?");
    $stmt->bind_param("ss", $login, $login);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return ['success' => false, 'error' => 'Неверный логин или пароль'];
    }
    
    $user = $result->fetch_assoc();
    
    // Проверяем пароль
    if (password_verify($password, $user['password'])) {
        // Сохраняем пользователя в сессии (без пароля)
        unset($user['password']);
        $_SESSION['user'] = $user;
        
        // Обновляем время последнего входа (если есть такое поле)
        $stmt = $db->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
        $stmt->bind_param("i", $user['id']);
        $stmt->execute();
        
        return ['success' => true, 'user' => $user];
    } else {
        return ['success' => false, 'error' => 'Неверный пароль'];
    }
}

/**
 * Выход пользователя
 */
function logoutUser() {
    // Удаляем все данные сессии
    session_unset();
    session_destroy();
    
    // Создаем новую сессию (опционально)
    session_start();
    
    return true;
}

/**
 * Проверка, авторизован ли пользователь
 */
function isLoggedIn() {
    return isset($_SESSION['user']) && !empty($_SESSION['user']);
}

/**
 * Проверка, является ли пользователь администратором
 */
function isAdmin() {
    return isLoggedIn() && $_SESSION['user']['role'] === 'admin';
}

/**
 * Получение данных текущего пользователя
 */
function getCurrentUser() {
    return isLoggedIn() ? $_SESSION['user'] : null;
}

/**
 * Получение ID текущего пользователя
 */
function getCurrentUserId() {
    return isLoggedIn() ? $_SESSION['user']['id'] : null;
}

/**
 * Проверка прав доступа к ресурсу
 */
function canEditRecipe($recipe_user_id) {
    if (!isLoggedIn()) return false;
    
    $current_user_id = getCurrentUserId();
    
    // Пользователь может редактировать свои рецепты
    // Администратор может редактировать все рецепты
    return $recipe_user_id == $current_user_id || isAdmin();
}

/**
 * Проверка прав доступа к пользователю
 */
function canEditUser($target_user_id) {
    if (!isLoggedIn()) return false;
    
    $current_user_id = getCurrentUserId();
    
    // Пользователь может редактировать только свой профиль
    // Администратор может редактировать всех пользователей
    return $target_user_id == $current_user_id || isAdmin();
}

/**
 * Обновление профиля пользователя
 */
function updateUserProfile($user_id, $data) {
    if (!canEditUser($user_id)) {
        return ['success' => false, 'error' => 'Нет прав для редактирования'];
    }
    
    $db = Database::connect();
    
    // Проверяем, существует ли пользователь
    $stmt = $db->prepare("SELECT id FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    
    if ($stmt->get_result()->num_rows === 0) {
        return ['success' => false, 'error' => 'Пользователь не найден'];
    }
    
    // Подготавливаем данные для обновления
    $updates = [];
    $params = [];
    $types = '';
    
    if (isset($data['username'])) {
        // Проверяем, не занят ли новый username
        $check_stmt = $db->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
        $check_stmt->bind_param("si", $data['username'], $user_id);
        $check_stmt->execute();
        
        if ($check_stmt->get_result()->num_rows > 0) {
            return ['success' => false, 'error' => 'Этот логин уже занят'];
        }
        
        $updates[] = "username = ?";
        $params[] = $data['username'];
        $types .= 's';
    }
    
    if (isset($data['email'])) {
        // Проверяем, не занят ли новый email
        $check_stmt = $db->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
        $check_stmt->bind_param("si", $data['email'], $user_id);
        $check_stmt->execute();
        
        if ($check_stmt->get_result()->num_rows > 0) {
            return ['success' => false, 'error' => 'Этот email уже занят'];
        }
        
        $updates[] = "email = ?";
        $params[] = $data['email'];
        $types .= 's';
    }
    
    if (isset($data['full_name'])) {
        $updates[] = "full_name = ?";
        $params[] = $data['full_name'];
        $types .= 's';
    }
    
    if (isset($data['password']) && !empty($data['password'])) {
        $hashed_password = password_hash($data['password'], PASSWORD_DEFAULT);
        $updates[] = "password = ?";
        $params[] = $hashed_password;
        $types .= 's';
    }
    
    // Администратор может менять роль
    if (isset($data['role']) && isAdmin()) {
        $updates[] = "role = ?";
        $params[] = $data['role'];
        $types .= 's';
    }
    
    if (empty($updates)) {
        return ['success' => false, 'error' => 'Нет данных для обновления'];
    }
    
    // Собираем SQL запрос
    $sql = "UPDATE users SET " . implode(', ', $updates) . " WHERE id = ?";
    $params[] = $user_id;
    $types .= 'i';
    
    $stmt = $db->prepare($sql);
    $stmt->bind_param($types, ...$params);
    
    if ($stmt->execute()) {
        // Обновляем данные в сессии, если это текущий пользователь
        if ($user_id == getCurrentUserId()) {
            $user_stmt = $db->prepare("SELECT id, username, email, full_name, role FROM users WHERE id = ?");
            $user_stmt->bind_param("i", $user_id);
            $user_stmt->execute();
            $_SESSION['user'] = $user_stmt->get_result()->fetch_assoc();
        }
        
        return ['success' => true];
    } else {
        return ['success' => false, 'error' => 'Ошибка при обновлении данных'];
    }
}

/**
 * Удаление пользователя (только для администратора)
 */
function deleteUser($user_id) {
    if (!isAdmin()) {
        return ['success' => false, 'error' => 'Только администратор может удалять пользователей'];
    }
    
    // Нельзя удалить самого себя
    if ($user_id == getCurrentUserId()) {
        return ['success' => false, 'error' => 'Нельзя удалить самого себя'];
    }
    
    $db = Database::connect();
    $stmt = $db->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    
    if ($stmt->execute()) {
        return ['success' => true];
    } else {
        return ['success' => false, 'error' => 'Ошибка при удалении пользователя'];
    }
}

/**
 * Получение пользователя по ID
 */
function getUserById($user_id) {
    $db = Database::connect();
    $stmt = $db->prepare("SELECT id, username, email, full_name, role, created_at FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->fetch_assoc();
}

/**
 * Получение всех пользователей (для администратора)
 */
function getAllUsers() {
    if (!isAdmin()) {
        return [];
    }
    
    $db = Database::connect();
    $result = $db->query("SELECT id, username, email, full_name, role, created_at FROM users ORDER BY created_at DESC");
    
    $users = [];
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
    
    return $users;
}

/**
 * Проверка авторизации и редирект если не авторизован
 */
function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: /pages/auth/login.php');
        exit();
    }
}

/**
 * Проверка прав администратора и редирект
 */
function requireAdmin() {
    requireLogin();
    
    if (!isAdmin()) {
        header('Location: /');
        exit();
    }
}

/**
 * Генерация CSRF токена
 */
function generateCsrfToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Проверка CSRF токена
 */
function verifyCsrfToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}
?>