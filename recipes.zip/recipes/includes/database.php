<?php
// database.php - подключение к БД
require_once 'config.php';

class Database {
    private static $connection = null;
    
    public static function connect() {
        if (self::$connection === null) {
            try {
                self::$connection = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
                
                if (self::$connection->connect_error) {
                    die("Ошибка подключения: " . self::$connection->connect_error);
                }
                
                self::$connection->set_charset("utf8mb4");
                echo "<!-- Подключение к БД успешно -->";
                
            } catch (Exception $e) {
                die("Ошибка базы данных: " . $e->getMessage());
            }
        }
        return self::$connection;
    }
    
    public static function query($sql, $params = []) {
        $conn = self::connect();
        $stmt = $conn->prepare($sql);
        
        if ($stmt === false) {
            return false;
        }
        
        if (!empty($params)) {
            $types = str_repeat('s', count($params));
            $stmt->bind_param($types, ...$params);
        }
        
        $stmt->execute();
        return $stmt;
    }
}

// Тестовое подключение (убрать потом)
$test_conn = Database::connect();
?>