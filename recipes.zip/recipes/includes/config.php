<?php
session_start();

// Настройки базы данных
define('DB_HOST', 'localhost');
define('DB_NAME', 'recipes_db');
define('DB_USER', 'root');
define('DB_PASS', '');
define('SITE_URL', 'http://localhost/recipes/');

// Настройки сайта
define('SITE_NAME', 'Кулинарные рецепты');
define('SITE_URL', 'http://localhost/recipes/');
define('UPLOAD_DIR', __DIR__ . '/../uploads/recipes/');

// Обработка ошибок
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Автоподключение классов
spl_autoload_register(function ($class) {
    require_once __DIR__ . '/' . $class . '.php';
});

// Подключаем вспомогательные функции
require_once 'functions.php';
?>