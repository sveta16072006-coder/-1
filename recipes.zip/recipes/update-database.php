<?php
// update-database.php - добавление изображений в базу данных
require_once 'includes/config.php';
require_once 'includes/database.php';

header('Content-Type: text/html; charset=utf-8');
echo '<h1>Обновление базы данных с изображениями</h1>';

$db = Database::connect();

// Маппинг изображений к рецептам
$image_mapping = [
    1 => 'uploads/recipes/images/borch.jpg',  // Борщ
    2 => 'uploads/recipes/images/olivie.jpg', // Оливье
    3 => 'uploads/recipes/images/pancakes.jpg' // Блины
];

// Дополнительные рецепты с изображениями
$additional_recipes = [
    [
        'title' => 'Котлеты домашние',
        'description' => 'Сочные домашние котлеты из свинины и говядины',
        'ingredients' => "Фарш мясной - 500г\nЛук репчатый - 1 шт\nХлеб белый - 100г\nМолоко - 100мл\nЯйцо - 1 шт\nСоль, перец - по вкусу\nСухари панировочные - для обсыпки",
        'instructions' => "1. Замочите хлеб в молоке\n2. Смешайте фарш с луком и яйцом\n3. Добавьте размоченный хлеб\n4. Посолите и поперчите\n5. Сформируйте котлеты и обваляйте в сухарях\n6. Жарьте на среднем огне по 5-7 минут с каждой стороны",
        'cooking_time' => 40,
        'difficulty' => 'easy',
        'category' => 'Мясные блюда',
        'image' => 'uploads/recipes/images/cutlets.jpg',
        'user_id' => 1
    ],
    [
        'title' => 'Торт Наполеон',
        'description' => 'Классический слоеный торт с заварным кремом',
        'ingredients' => "Мука - 500г\nМасло сливочное - 400г\nВода холодная - 200мл\nЯйца - 2 шт\nСоль - щепотка\nМолоко - 1л\nСахар - 300г\nЯйца для крема - 3 шт\nМука для крема - 100г\nВанилин - по вкусу",
        'instructions' => "1. Приготовьте слоеное тесто\n2. Раскатайте и испеките коржи\n3. Приготовьте заварной крем\n4. Промажьте коржи кремом\n5. Оставьте торт на ночь для пропитки\n6. Украсьте крошкой от коржей",
        'cooking_time' => 180,
        'difficulty' => 'hard',
        'category' => 'Десерты',
        'image' => 'uploads/recipes/images/cake.jpg',
        'user_id' => 1
    ]
];

// Обновляем существующие рецепты
echo '<h2>Обновление существующих рецептов:</h2>';
foreach ($image_mapping as $recipe_id => $image_path) {
    // Проверяем существует ли рецепт
    $stmt = $db->prepare("SELECT id FROM recipes WHERE id = ?");
    $stmt->bind_param("i", $recipe_id);
    $stmt->execute();
    
    if ($stmt->get_result()->num_rows > 0) {
        // Обновляем изображение
        $stmt = $db->prepare("UPDATE recipes SET image = ? WHERE id = ?");
        $stmt->bind_param("si", $image_path, $recipe_id);
        
        if ($stmt->execute()) {
            echo "<p>✅ Рецепт #$recipe_id обновлен с изображением: " . basename($image_path) . "</p>";
        } else {
            echo "<p>❌ Ошибка обновления рецепта #$recipe_id</p>";
        }
    } else {
        echo "<p>⚠️ Рецепт #$recipe_id не найден в базе</p>";
    }
}

// Добавляем новые рецепты
echo '<h2>Добавление новых рецептов:</h2>';
foreach ($additional_recipes as $recipe) {
    $stmt = $db->prepare("INSERT INTO recipes (user_id, title, description, ingredients, instructions, cooking_time, difficulty, category, image) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issssiss", 
        $recipe['user_id'],
        $recipe['title'],
        $recipe['description'],
        $recipe['ingredients'],
        $recipe['instructions'],
        $recipe['cooking_time'],
        $recipe['difficulty'],
        $recipe['category'],
        $recipe['image']
    );
    
    if ($stmt->execute()) {
        echo "<p>✅ Добавлен рецепт: {$recipe['title']}</p>";
    } else {
        echo "<p>❌ Ошибка добавления рецепта: {$recipe['title']}</p>";
    }
}

// Обновляем все рецепты чтобы добавить просмотры (для реалистичности)
echo '<h2>Обновление статистики:</h2>';
$db->query("UPDATE recipes SET views = FLOOR(RAND() * 100) + 1");

$result = $db->query("SELECT COUNT(*) as count, SUM(views) as total_views FROM recipes");
$stats = $result->fetch_assoc();

echo "<p>Всего рецептов в базе: <strong>{$stats['count']}</strong></p>";
echo "<p>Общее количество просмотров: <strong>{$stats['total_views']}</strong></p>";

echo '<h2>Готово! Теперь в вашей базе есть:</h2>';
$recipes = $db->query("SELECT id, title, category, image, views FROM recipes ORDER BY id");
echo '<ul>';
while ($row = $recipes->fetch_assoc()) {
    $has_image = !empty($row['image']) ? '✅' : '❌';
    echo "<li>#{$row['id']}: {$row['title']} ({$row['category']}) $has_image 👁️ {$row['views']}</li>";
}
echo '</ul>';

echo '<p><a href="index.php">Перейти на главную</a></p>';
?>