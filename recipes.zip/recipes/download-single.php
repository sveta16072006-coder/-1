<?php
// download-single.php - скачивание одного изображения через AJAX
header('Content-Type: application/json');

$url = $_POST['url'] ?? '';
$filename = $_POST['name'] ?? '';

if (empty($url) || empty($filename)) {
    echo json_encode(['success' => false, 'error' => 'Не указаны параметры']);
    exit;
}

// Создаем папку если нет
$upload_dir = 'uploads/recipes/images/';
if (!file_exists($upload_dir)) {
    mkdir($upload_dir, 0777, true);
}

$filepath = $upload_dir . $filename;

// Пробуем скачать
$success = false;
$error = '';
$size = 0;

// Способ 1: file_get_contents (самый простой)
if (ini_get('allow_url_fopen')) {
    $context = stream_context_create([
        'ssl' => [
            'verify_peer' => false,
            'verify_peer_name' => false,
        ],
        'http' => [
            'header' => "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36\r\n",
            'timeout' => 30
        ]
    ]);
    
    $image_data = @file_get_contents($url, false, $context);
    
    if ($image_data !== false && file_put_contents($filepath, $image_data)) {
        $success = true;
        $size = filesize($filepath);
    } else {
        $error = 'Не удалось скачать через file_get_contents';
    }
}

// Способ 2: cURL (если первый не сработал)
if (!$success && function_exists('curl_init')) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    
    $image_data = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    
    if ($http_code === 200 && $image_data !== false && file_put_contents($filepath, $image_data)) {
        $success = true;
        $size = filesize($filepath);
    } else {
        $error = 'Не удалось скачать через cURL (код: ' . $http_code . ')';
    }
    
    curl_close($ch);
}

if ($success) {
    $size_kb = round($size / 1024, 1);
    echo json_encode([
        'success' => true,
        'filename' => $filename,
        'path' => $filepath,
        'size' => $size_kb . ' KB',
        'message' => 'Успешно скачано'
    ]);
} else {
    // Пробуем создать тестовое изображение как запасной вариант
    $image = imagecreatetruecolor(800, 600);
    
    // Цвета для разных блюд
    switch($filename) {
        case 'borch.jpg': $color = imagecolorallocate($image, 180, 60, 60); break; // Красный
        case 'olivie.jpg': $color = imagecolorallocate($image, 100, 180, 100); break; // Зеленый
        case 'pancakes.jpg': $color = imagecolorallocate($image, 255, 220, 100); break; // Желтый
        case 'cutlets.jpg': $color = imagecolorallocate($image, 180, 120, 80); break; // Коричневый
        case 'cake.jpg': $color = imagecolorallocate($image, 255, 200, 220); break; // Розовый
        default: $color = imagecolorallocate($image, 200, 200, 200);
    }
    
    imagefill($image, 0, 0, $color);
    
    // Добавляем текст с названием
    $text_color = imagecolorallocate($image, 255, 255, 255);
    $title = strtoupper(str_replace('.jpg', '', $filename));
    imagettftext($image, 40, 0, 100, 300, $text_color, dirname(__FILE__) . '/arial.ttf', $title);
    
    // Сохраняем
    imagejpeg($image, $filepath, 90);
    imagedestroy($image);
    
    $size = filesize($filepath);
    $size_kb = round($size / 1024, 1);
    
    echo json_encode([
        'success' => true,
        'filename' => $filename,
        'path' => $filepath,
        'size' => $size_kb . ' KB',
        'message' => 'Создано тестовое изображение (не удалось скачать оригинал)'
    ]);
}
?>