<?php
// download-images-fixed.php - с рабочей ссылкой на оливье
header('Content-Type: text/html; charset=utf-8');
echo '<!DOCTYPE html>
<html>
<head>
    <title>Скачивание изображений для рецептов</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 900px;
            margin: 40px auto;
            background: white;
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        h1 {
            color: #2c3e50;
            margin-bottom: 30px;
            text-align: center;
            font-size: 2.5em;
            background: linear-gradient(90deg, #667eea, #764ba2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .image-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 20px;
            margin: 30px 0;
        }
        .image-card {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 15px;
            text-align: center;
            transition: all 0.3s ease;
            border: 2px solid transparent;
        }
        .image-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
            border-color: #667eea;
        }
        .image-preview {
            width: 100%;
            height: 120px;
            object-fit: cover;
            border-radius: 10px;
            margin-bottom: 10px;
        }
        .status {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.9em;
            font-weight: bold;
            margin: 5px 0;
            display: inline-block;
        }
        .status-success {
            background: #d4edda;
            color: #155724;
        }
        .status-error {
            background: #f8d7da;
            color: #721c24;
        }
        .status-warning {
            background: #fff3cd;
            color: #856404;
        }
        .btn {
            display: inline-block;
            background: linear-gradient(90deg, #667eea, #764ba2);
            color: white;
            padding: 15px 30px;
            border: none;
            border-radius: 50px;
            font-size: 1.1em;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.3s ease;
            margin: 10px;
            text-align: center;
        }
        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.4);
        }
        .btn-success {
            background: linear-gradient(90deg, #2ecc71, #27ae60);
        }
        .progress-bar {
            width: 100%;
            height: 20px;
            background: #f0f0f0;
            border-radius: 10px;
            margin: 20px 0;
            overflow: hidden;
        }
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #667eea, #764ba2);
            border-radius: 10px;
            transition: width 0.5s ease;
            width: 0%;
        }
        .result-box {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 25px;
            margin-top: 30px;
            border-left: 5px solid #667eea;
        }
        .filename {
            font-family: monospace;
            background: #2c3e50;
            color: white;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 0.9em;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🍳 Скачивание изображений для рецептов</h1>
        
        <div class="progress-bar">
            <div class="progress-fill" id="progress-bar"></div>
        </div>
        
        <div id="status-message" style="text-align: center; margin: 20px 0; font-size: 1.1em;"></div>
        
        <div class="image-grid" id="image-grid">';

// ВСЕ РАБОЧИЕ ССЫЛКИ (проверенные)
$images = [
    [
        'url' => 'https://mir-s3-cdn-cf.behance.net/project_modules/max_1200/2e536397342511.5ec2f4013a57f.jpg',
        'name' => 'borch.jpg',
        'recipe_id' => 1,
        'title' => 'Борщ'
    ],
    [
        'url' => 'https://main-cdn.sbermegamarket.ru/big1/hlr-system/-14/920/313/191/216/223/1/100045564295b0.jpg',
        'name' => 'olivie.jpg',
        'recipe_id' => 2,
        'title' => 'Салат Оливье'
    ],
    [
        'url' => 'https://img.freepik.com/premium-photo/delicious-pancakes-rolled-isolated_183352-2476.jpg',
        'name' => 'pancakes.jpg',
        'recipe_id' => 3,
        'title' => 'Домашние блины'
    ],
    [
        'url' => 'https://main-cdn.sbermegamarket.ru/big1/hlr-system/-75/917/986/812/261/30/100062519008b0.jpg',
        'name' => 'cutlets.jpg',
        'recipe_id' => 4,
        'title' => 'Котлеты домашние'
    ],
    [
        'url' => 'https://main-cdn.sbermegamarket.ru/big2/hlr-system/-18/566/626/021/420/1/100030440255b0.jpg',
        'name' => 'cake.jpg',
        'recipe_id' => 5,
        'title' => 'Торт Наполеон'
    ]
];

// Показываем карточки изображений
foreach ($images as $image) {
    $filepath = 'uploads/recipes/images/' . $image['name'];
    $exists = file_exists($filepath);
    
    echo '<div class="image-card">
            <div style="font-size: 2em; margin-bottom: 10px;">';
    
    // Иконки для разных типов блюд
    switch ($image['name']) {
        case 'borch.jpg': echo '🍲'; break;
        case 'olivie.jpg': echo '🥗'; break;
        case 'pancakes.jpg': echo '🥞'; break;
        case 'cutlets.jpg': echo '🍖'; break;
        case 'cake.jpg': echo '🍰'; break;
        default: echo '🍳';
    }
    
    echo '</div>
            <h4 style="margin-bottom: 10px; color: #2c3e50;">' . $image['title'] . '</h4>
            <div class="filename">' . $image['name'] . '</div>';
    
    if ($exists) {
        $size = round(filesize($filepath) / 1024, 1);
        echo '<div class="status status-success">✓ Уже есть (' . $size . ' KB)</div>';
        echo '<img src="' . $filepath . '" class="image-preview">';
    } else {
        echo '<div class="status status-warning">⏳ Ожидает загрузки</div>';
        echo '<div style="width: 100%; height: 120px; background: linear-gradient(135deg, #f5f7fa, #c3cfe2); border-radius: 10px; display: flex; align-items: center; justify-content: center; color: #666; font-size: 2em;">
                ⏳
              </div>';
    }
    
    echo '</div>';
}

echo '</div>';

// Кнопки действий
echo '<div style="text-align: center; margin-top: 40px;">
        <button class="btn" onclick="downloadAllImages()" id="download-btn">
            ⬇️ Скачать все изображения
        </button>
        <a href="update-database.php" class="btn btn-success" id="update-btn" style="display: none;">
            🗄️ Обновить базу данных
        </a>
        <a href="index.php" class="btn" style="background: #95a5a6;">
            🏠 На главную
        </a>
      </div>
      
      <div class="result-box" id="result-box" style="display: none;">
        <h3 style="margin-bottom: 15px;">📊 Результат скачивания:</h3>
        <div id="result-content"></div>
      </div>
    </div>
    
    <script>
    let totalImages = ' . count($images) . ';
    let downloaded = 0;
    
    function downloadAllImages() {
        document.getElementById("download-btn").disabled = true;
        document.getElementById("download-btn").innerHTML = "⏳ Скачивание...";
        document.getElementById("result-box").style.display = "block";
        
        let images = ' . json_encode($images) . ';
        downloaded = 0;
        
        images.forEach((image, index) => {
            setTimeout(() => {
                downloadImage(image, index);
            }, index * 1000); // Задержка между загрузками
        });
    }
    
    function downloadImage(image, index) {
        let xhr = new XMLHttpRequest();
        xhr.open("POST", "download-single.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        
        xhr.onload = function() {
            if (xhr.status === 200) {
                let response = JSON.parse(xhr.responseText);
                updateImageCard(image.name, response);
                
                if (response.success) {
                    downloaded++;
                    updateProgress();
                }
                
                if (downloaded === totalImages) {
                    finishDownload();
                }
            }
        };
        
        xhr.send("url=" + encodeURIComponent(image.url) + "&name=" + encodeURIComponent(image.name));
    }
    
    function updateImageCard(filename, response) {
        let cards = document.querySelectorAll(".image-card");
        cards.forEach(card => {
            if (card.querySelector(".filename").textContent === filename) {
                let statusDiv = card.querySelector(".status");
                let previewDiv = card.querySelector(".image-preview") || card.querySelector("div[style*=\"background: linear-gradient\"]");
                
                if (response.success) {
                    statusDiv.className = "status status-success";
                    statusDiv.innerHTML = "✓ Скачано (" + response.size + " KB)";
                    
                    if (previewDiv) {
                        previewDiv.outerHTML = \'<img src="\' + response.path + \'" class="image-preview">\';
                    }
                } else {
                    statusDiv.className = "status status-error";
                    statusDiv.innerHTML = "✗ Ошибка: " + response.error;
                }
            }
        });
    }
    
    function updateProgress() {
        let percent = Math.round((downloaded / totalImages) * 100);
        document.getElementById("progress-bar").style.width = percent + "%";
        document.getElementById("status-message").innerHTML = "Скачано: " + downloaded + " из " + totalImages + " (" + percent + "%)";
    }
    
    function finishDownload() {
        document.getElementById("download-btn").style.display = "none";
        document.getElementById("update-btn").style.display = "inline-block";
        document.getElementById("status-message").innerHTML = "✅ Все изображения успешно скачаны!";
        document.getElementById("status-message").style.color = "#2ecc71";
        
        document.getElementById("result-content").innerHTML = \'
            <div style="color: #2ecc71; font-weight: bold; margin: 10px 0;">🎉 Все 5 изображений успешно скачаны!</div>
            <p>Изображения сохранены в папку: <code>uploads/recipes/images/</code></p>
            <p>Теперь вы можете обновить базу данных, чтобы привязать изображения к рецептам.</p>
        \';
    }
    
    // Проверяем сколько файлов уже скачано
    window.onload = function() {
        let existing = 0;
        let images = ' . json_encode($images) . ';
        
        images.forEach(image => {
            if (fileExists("uploads/recipes/images/" + image.name)) {
                existing++;
            }
        });
        
        downloaded = existing;
        updateProgress();
        
        if (existing === totalImages) {
            document.getElementById("download-btn").style.display = "none";
            document.getElementById("update-btn").style.display = "inline-block";
            document.getElementById("status-message").innerHTML = "✅ Все изображения уже скачаны!";
            document.getElementById("result-box").style.display = "block";
            document.getElementById("result-content").innerHTML = \'
                <div style="color: #2ecc71; font-weight: bold; margin: 10px 0;">✅ Все изображения уже скачаны!</div>
                <p>Можете обновить базу данных.</p>
            \';
        }
    };
    
    function fileExists(url) {
        var xhr = new XMLHttpRequest();
        xhr.open("HEAD", url, false);
        try {
            xhr.send();
            return xhr.status !== 404;
        } catch(e) {
            return false;
        }
    }
    </script>
</body>
</html>';
?>