<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Кулинарные рецепты</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <h1>Добро пожаловать на сайт рецептов!</h1>
    <p>Проект успешно создан!</p>
    
    <nav>
        <a href="pages/auth/login.php">Вход</a> | <!-- ИСПРАВЛЕНО -->
        <a href="pages/auth/register.php">Регистрация</a> <!-- ИСПРАВЛЕНО -->
    </nav>
    
    <?php
    // Подключаем конфигурацию
   require_once __DIR__ . '/includes/config.php';
    
    echo "<p>Текущая дата: " . date('d.m.Y H:i:s') . "</p>";
    
    // Проверка PHP
    if (function_exists('mysqli_connect')) {
        echo "<p style='color:green;'>✓ PHP MySQL работает</p>";
    } else {
        echo "<p style='color:red;'>✗ PHP MySQL не настроен</p>";
    }
    
    // Проверка сессии
    if (isset($_SESSION['user'])) {
        echo "<p>Вы вошли как: " . $_SESSION['user']['username'] . "</p>";
    }
    ?>
</body>
</html>