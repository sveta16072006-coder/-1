<?php
// quick-fix.php - быстрые исправления
echo '<h1>Применение быстрых исправлений</h1>';

// 1. Исправляем index.php
$index_content = file_get_contents('index.php');
$index_content = str_replace(
    "require_once 'includes/config.php';",
    "require_once __DIR__ . '/includes/config.php';",
    $index_content
);
file_put_contents('index.php', $index_content);
echo '✅ index.php исправлен<br>';

// 2. Исправляем config.php
$config_content = file_get_contents('includes/config.php');
if (!strpos($config_content, "define('SITE_URL'")) {
    $config_content = str_replace(
        "define('DB_PASS', '');",
        "define('DB_PASS', '');\n\ndefine('SITE_URL', 'http://localhost/recipes/');",
        $config_content
);
    file_put_contents('includes/config.php', $config_content);
    echo '✅ config.php исправлен<br>';
}

// 3. Создаем недостающие файлы
$files = [
    'includes/functions.php' => "<?php\n// functions.php\nrequire_once 'config.php';\n\nfunction isLoggedIn() {\n    return isset(\$_SESSION['user']);\n}\n\nfunction redirect(\$url) {\n    header('Location: ' . SITE_URL . \$url);\n    exit();\n}\n?>",
    
    'pages/auth/logout.php' => "<?php\nrequire_once __DIR__ . '/../../includes/config.php';\nsession_destroy();\nheader('Location: ' . SITE_URL);\nexit();\n?>",
    
    'pages/user/profile.php' => "<?php\nrequire_once __DIR__ . '/../../includes/config.php';\nrequire_once __DIR__ . '/../../includes/auth.php';\n\nif (!isset(\$_SESSION['user'])) {\n    header('Location: ' . SITE_URL . 'pages/auth/login.php');\n    exit();\n}\n\n\$user = \$_SESSION['user'];\n?>\n<!DOCTYPE html>\n<html>\n<head>\n    <title>Профиль</title>\n    <link rel='stylesheet' href='<?= SITE_URL ?>assets/css/style.css'>\n</head>\n<body>\n    <div style='max-width:800px; margin:0 auto; padding:20px;'>\n        <h1>Мой профиль</h1>\n        <p>Имя: <?= \$user['username'] ?></p>\n        <a href='<?= SITE_URL ?>'>На главную</a>\n    </div>\n</body>\n</html>"
];

foreach ($files as $path => $content) {
    if (!file_exists($path)) {
        $dir = dirname($path);
        if (!is_dir($dir)) {
            mkdir($dir, 0777, true);
        }
        file_put_contents($path, $content);
        echo "✅ Создан файл: $path<br>";
    }
}

echo '<h2>✅ Исправления применены!</h2>';
echo '<a href="index.php">Перейти на главную</a>';
?>