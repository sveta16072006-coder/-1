<?php
// Страница просмотра рецепта
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/database.php';

$db = Database::connect();

// Получаем ID рецепта
$recipe_id = $_GET['id'] ?? 0;
if (!$recipe_id) {
    header('Location: index.php');
    exit();
}

// Увеличиваем счетчик просмотров
$db->query("UPDATE recipes SET views = views + 1 WHERE id = $recipe_id");

// Получаем данные рецепта
$stmt = $db->prepare("SELECT r.*, u.username, u.id as user_id FROM recipes r JOIN users u ON r.user_id = u.id WHERE r.id = ?");
$stmt->bind_param("i", $recipe_id);
$stmt->execute();
$recipe = $stmt->get_result()->fetch_assoc();

if (!$recipe) {
    header('Location: index.php');
    exit();
}

$page_title = $recipe['title'] . " - " . SITE_NAME;

// Получаем похожие рецепты
$similar_stmt = $db->prepare("SELECT id, title, image, cooking_time, difficulty FROM recipes WHERE category = ? AND id != ? LIMIT 3");
$similar_stmt->bind_param("si", $recipe['category'], $recipe_id);
$similar_stmt->execute();
$similar_recipes = $similar_stmt->get_result();

// Проверяем, может ли пользователь редактировать рецепт
$can_edit = canEditRecipe($recipe['user_id']);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    <link rel="stylesheet" href="<?= SITE_URL ?>assets/css/style.css">
    <style>
        .recipe-view-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .recipe-header {
            background: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .recipe-title {
            color: #2c3e50;
            margin-bottom: 15px;
            font-size: 2.2em;
        }
        
        .recipe-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            margin: 20px 0;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 5px;
        }
        
        .meta-item {
            display: flex;
            align-items: center;
            gap: 8px;
            color: #666;
        }
        
        .recipe-image {
            width: 100%;
            max-height: 400px;
            object-fit: cover;
            border-radius: 10px;
            margin: 20px 0;
        }
        
        .recipe-content {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 40px;
            margin: 40px 0;
        }
        
        @media (max-width: 768px) {
            .recipe-content {
                grid-template-columns: 1fr;
            }
        }
        
        .ingredients-section,
        .instructions-section {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .section-title {
            color: #2c3e50;
            border-bottom: 2px solid #3498db;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        
        .ingredients-list {
            list-style: none;
        }
        
        .ingredients-list li {
            padding: 10px 0;
            border-bottom: 1px solid #eee;
            display: flex;
            align-items: center;
        }
        
        .ingredients-list li:before {
            content: "•";
            color: #3498db;
            font-weight: bold;
            font-size: 1.5em;
            margin-right: 15px;
        }
        
        .instructions-text {
            line-height: 1.8;
            white-space: pre-line;
        }
        
        .recipe-actions {
            display: flex;
            gap: 15px;
            margin: 30px 0;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }
        
        .author-info {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-top: 30px;
            display: flex;
            align-items: center;
            gap: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .author-avatar {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, #3498db, #2ecc71);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5em;
            font-weight: bold;
        }
        
        .similar-recipes {
            margin-top: 50px;
        }
        
        .similar-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        
        .similar-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-decoration: none;
            color: inherit;
            transition: transform 0.3s;
        }
        
        .similar-card:hover {
            transform: translateY(-5px);
        }
        
        .difficulty-badge {
            display: inline-block;
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 0.8em;
            font-weight: bold;
            margin-top: 5px;
        }
        
        .difficulty-easy { background: #2ecc71; color: white; }
        .difficulty-medium { background: #f39c12; color: white; }
        .difficulty-hard { background: #e74c3c; color: white; }
        
        .print-btn, .back-btn, .edit-btn, .delete-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
        }
        
        .print-btn {
            background: #3498db;
            color: white;
        }
        
        .back-btn {
            background: #95a5a6;
            color: white;
        }
        
        .edit-btn {
            background: #2ecc71;
            color: white;
        }
        
        .delete-btn {
            background: #e74c3c;
            color: white;
        }
        
        .empty-image {
            height: 300px;
            background: linear-gradient(135deg, #f5f7fa, #c3cfe2);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #7f8c8d;
            font-size: 4em;
        }
        
        @media print {
            .recipe-actions,
            .similar-recipes,
            .author-info,
            nav {
                display: none !important;
            }
            
            body {
                font-size: 12pt;
                line-height: 1.5;
            }
            
            .recipe-content {
                grid-template-columns: 1fr;
                gap: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="recipe-view-container">
        <!-- Навигация -->
        <nav style="margin-bottom: 20px;">
            <a href="<?= SITE_URL ?>">← На главную</a> | 
            <a href="index.php">← Все рецепты</a>
            <?php if (isLoggedIn()): ?>
                | <a href="../user/profile.php">👤 Мой профиль</a>
            <?php endif; ?>
        </nav>

        <!-- Шапка рецепта -->
        <div class="recipe-header">
            <h1 class="recipe-title"><?= htmlspecialchars($recipe['title']) ?></h1>
            
            <?php if (!empty($recipe['description'])): ?>
                <p style="font-size: 1.2em; color: #666; margin-bottom: 20px;">
                    <?= htmlspecialchars($recipe['description']) ?>
                </p>
            <?php endif; ?>
            
            <div class="recipe-meta">
                <div class="meta-item">
                    <span>👤 Автор:</span>
                    <strong><?= htmlspecialchars($recipe['username']) ?></strong>
                </div>
                <div class="meta-item">
                    <span>⏱️ Время приготовления:</span>
                    <strong><?= $recipe['cooking_time'] ?> минут</strong>
                </div>
                <div class="meta-item">
                    <span>⚡ Сложность:</span>
                    <span class="difficulty-badge difficulty-<?= $recipe['difficulty'] ?>">
                        <?= $recipe['difficulty'] == 'easy' ? 'Легкая' : 
                              ($recipe['difficulty'] == 'medium' ? 'Средняя' : 'Сложная') ?>
                    </span>
                </div>
                <div class="meta-item">
                    <span>🏷️ Категория:</span>
                    <strong><?= htmlspecialchars($recipe['category'] ?? 'Не указана') ?></strong>
                </div>
                <div class="meta-item">
                    <span>👁️ Просмотров:</span>
                    <strong><?= $recipe['views'] ?></strong>
                </div>
                <div class="meta-item">
                    <span>📅 Дата публикации:</span>
                    <strong><?= date('d.m.Y H:i', strtotime($recipe['created_at'])) ?></strong>
                </div>
            </div>
            
            <!-- Изображение рецепта -->
            <?php if (!empty($recipe['image'])): ?>
                <img src="<?= SITE_URL . htmlspecialchars($recipe['image']) ?>" 
                     alt="<?= htmlspecialchars($recipe['title']) ?>" 
                     class="recipe-image">
            <?php else: ?>
                <div class="empty-image">
                    🍳
                </div>
            <?php endif; ?>
        </div>

        <!-- Кнопки действий -->
        <div class="recipe-actions">
            <a href="javascript:window.print()" class="print-btn">🖨️ Распечатать рецепт</a>
            <a href="index.php" class="back-btn">← Назад к рецептам</a>
            
            <?php if ($can_edit): ?>
                <a href="?edit=<?= $recipe['id'] ?>" class="edit-btn">✏️ Редактировать</a>
                <a href="?delete=<?= $recipe['id'] ?>" class="delete-btn" 
                   onclick="return confirm('Удалить рецепт «<?= htmlspecialchars(addslashes($recipe['title'])) ?>»?')">
                    🗑️ Удалить
                </a>
            <?php endif; ?>
        </div>

        <!-- Основное содержание -->
        <div class="recipe-content">
            <!-- Ингредиенты -->
            <div class="ingredients-section">
                <h2 class="section-title">Ингредиенты</h2>
                <ul class="ingredients-list">
                    <?php 
                    $ingredients = explode("\n", $recipe['ingredients']);
                    foreach ($ingredients as $ingredient):
                        $ingredient = trim($ingredient);
                        if (!empty($ingredient)):
                    ?>
                        <li><?= htmlspecialchars($ingredient) ?></li>
                    <?php 
                        endif;
                    endforeach; 
                    ?>
                </ul>
            </div>

            <!-- Инструкция -->
            <div class="instructions-section">
                <h2 class="section-title">Способ приготовления</h2>
                <div class="instructions-text">
                    <?= nl2br(htmlspecialchars($recipe['instructions'])) ?>
                </div>
            </div>
        </div>

        <!-- Информация об авторе -->
        <div class="author-info">
            <div class="author-avatar">
                <?= strtoupper(substr($recipe['username'], 0, 1)) ?>
            </div>
            <div>
                <h3 style="margin: 0 0 5px 0;">Автор рецепта</h3>
                <p style="margin: 0; color: #666;">
                    <strong><?= htmlspecialchars($recipe['username']) ?></strong>
                </p>
                <p style="margin: 5px 0 0 0; color: #666; font-size: 0.9em;">
                    Рецепт опубликован: <?= date('d.m.Y', strtotime($recipe['created_at'])) ?>
                </p>
            </div>
        </div>

        <!-- Похожие рецепты -->
        <?php if ($similar_recipes->num_rows > 0): ?>
            <div class="similar-recipes">
                <h2>Похожие рецепты</h2>
                <div class="similar-grid">
                    <?php while ($similar = $similar_recipes->fetch_assoc()): ?>
                        <a href="view.php?id=<?= $similar['id'] ?>" class="similar-card">
                            <h4 style="margin: 0 0 10px 0; color: #2c3e50;">
                                <?= htmlspecialchars($similar['title']) ?>
                            </h4>
                            <div style="color: #666; font-size: 0.9em;">
                                <div>⏱️ <?= $similar['cooking_time'] ?> мин</div>
                                <span class="difficulty-badge difficulty-<?= $similar['difficulty'] ?>">
                                    <?= $similar['difficulty'] == 'easy' ? 'Легко' : 
                                          ($similar['difficulty'] == 'medium' ? 'Средне' : 'Сложно') ?>
                                </span>
                            </div>
                        </a>
                    <?php endwhile; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script>
        // Автоматическое форматирование инструкций
        document.querySelectorAll('.instructions-text').forEach(element => {
            const text = element.textContent;
            // Добавляем нумерацию шагов
            const steps = text.split(/\n+/).filter(step => step.trim());
            if (steps.length > 1) {
                let formatted = '';
                steps.forEach((step, index) => {
                    formatted += `<div style="margin-bottom: 15px;">
                        <strong style="color: #3498db;">Шаг ${index + 1}.</strong>
                        <span>${step.trim()}</span>
                    </div>`;
                });
                element.innerHTML = formatted;
            }
        });
        
        // Подсветка ингредиентов при наведении
        document.querySelectorAll('.ingredients-list li').forEach(item => {
            item.addEventListener('mouseenter', function() {
                this.style.backgroundColor = '#f8f9fa';
                this.style.paddingLeft = '25px';
                this.style.transition = 'all 0.3s';
            });
            
            item.addEventListener('mouseleave', function() {
                this.style.backgroundColor = '';
                this.style.paddingLeft = '';
            });
        });
    </script>
</body>
</html>