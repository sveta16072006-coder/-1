<?php
require_once '../../includes/config.php';
require_once '../../includes/database.php';

$recipes = getRecipes();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Все рецепты - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="<?= SITE_URL ?>assets/css/style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Все рецепты</h1>
            <nav>
                <a href="<?= SITE_URL ?>">Главная</a>
                <?php if (isLoggedIn()): ?>
                    <a href="<?= SITE_URL ?>pages/user/profile.php">Профиль</a>
                    <?php if (isAdmin()): ?>
                        <a href="<?= SITE_URL ?>pages/admin/">Админка</a>
                    <?php endif; ?>
                    <a href="<?= SITE_URL ?>pages/auth/logout.php">Выйти</a>
                <?php else: ?>
                    <a href="<?= SITE_URL ?>pages/auth/login.php">Вход</a>
                    <a href="<?= SITE_URL ?>pages/auth/register.php">Регистрация</a>
                <?php endif; ?>
            </nav>
        </header>

        <div class="recipes-grid">
            <?php foreach ($recipes as $recipe): ?>
                <div class="recipe-card">
                    <h3><?= escape($recipe['title']) ?></h3>
                    <p><?= escape(substr($recipe['description'], 0, 100)) ?>...</p>
                    <div class="recipe-meta">
                        <span>Время: <?= $recipe['cooking_time'] ?> мин.</span>
                        <span>Сложность: <?= $recipe['difficulty'] ?></span>
                        <span>Автор: <?= escape($recipe['username']) ?></span>
                    </div>
                    <a href="view.php?id=<?= $recipe['id'] ?>" class="btn">Посмотреть</a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</body>
</html>