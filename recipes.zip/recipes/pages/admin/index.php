<?php
// Главная страница админ-панели
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/auth.php';

// Только для администраторов
requireAdmin();

// Подключаем базу данных
require_once __DIR__ . '/../../includes/database.php';

// Получаем статистику
$db = Database::connect();

// Количество пользователей
$result = $db->query("SELECT COUNT(*) as count FROM users");
$users_count = $result->fetch_assoc()['count'];

// Количество рецептов
$result = $db->query("SELECT COUNT(*) as count FROM recipes");
$recipes_count = $result->fetch_assoc()['count'];

// Последние 5 пользователей
$result = $db->query("SELECT id, username, email, role, created_at FROM users ORDER BY created_at DESC LIMIT 5");
$latest_users = [];
while ($row = $result->fetch_assoc()) {
    $latest_users[] = $row;
}

// Последние 5 рецептов
$result = $db->query("SELECT r.id, r.title, u.username, r.created_at FROM recipes r JOIN users u ON r.user_id = u.id ORDER BY r.created_at DESC LIMIT 5");
$latest_recipes = [];
while ($row = $result->fetch_assoc()) {
    $latest_recipes[] = $row;
}

$page_title = "Админ-панель";
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Админ-панель - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="<?= SITE_URL ?>assets/css/style.css">
    <style>
        .admin-dashboard {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin: 30px 0;
        }
        
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
            transition: transform 0.3s;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-number {
            font-size: 2.5em;
            font-weight: bold;
            color: #3498db;
            margin: 10px 0;
        }
        
        .stat-label {
            color: #666;
            font-size: 1.1em;
        }
        
        .recent-activity {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(500px, 1fr));
            gap: 20px;
            margin-top: 40px;
        }
        
        .activity-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .activity-card h3 {
            border-bottom: 2px solid #3498db;
            padding-bottom: 10px;
            margin-bottom: 20px;
            color: #2c3e50;
        }
        
        .activity-list {
            list-style: none;
        }
        
        .activity-item {
            padding: 12px 0;
            border-bottom: 1px solid #eee;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .activity-item:last-child {
            border-bottom: none;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            background: #3498db;
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }
        
        .quick-actions {
            display: flex;
            gap: 10px;
            margin-top: 30px;
            flex-wrap: wrap;
        }
        
        .btn-admin {
            background: #2c3e50;
            color: white;
            padding: 12px 25px;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-admin:hover {
            background: #34495e;
        }
        
        @media (max-width: 768px) {
            .recent-activity {
                grid-template-columns: 1fr;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="admin-dashboard">
        <header>
            <h1>Админ-панель</h1>
            <nav>
                <a href="<?= SITE_URL ?>">← На главную</a>
                <a href="users.php">👥 Пользователи</a>
                <a href="recipes.php">🍳 Рецепты</a>
                <a href="<?= SITE_URL ?>pages/auth/logout.php">🚪 Выйти (<?= $_SESSION['user']['username'] ?>)</a>
            </nav>
        </header>

        <!-- Статистика -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number"><?= $users_count ?></div>
                <div class="stat-label">Пользователей</div>
                <a href="users.php" style="color: #3498db; text-decoration: none; margin-top: 10px; display: inline-block;">
                    Посмотреть всех →
                </a>
            </div>
            
            <div class="stat-card">
                <div class="stat-number"><?= $recipes_count ?></div>
                <div class="stat-label">Рецептов</div>
                <a href="recipes.php" style="color: #3498db; text-decoration: none; margin-top: 10px; display: inline-block;">
                    Посмотреть все →
                </a>
            </div>
            
            <div class="stat-card">
                <div class="stat-number"><?= date('H:i') ?></div>
                <div class="stat-label">Текущее время</div>
                <div style="color: #666; margin-top: 10px;"><?= date('d.m.Y') ?></div>
            </div>
        </div>

        <!-- Быстрые действия -->
        <div class="quick-actions">
            <a href="users.php?action=add" class="btn-admin">➕ Добавить пользователя</a>
            <a href="recipes.php?action=add" class="btn-admin">🍳 Добавить рецепт</a>
            <a href="<?= SITE_URL ?>pages/user/profile.php" class="btn-admin">👤 Мой профиль</a>
            <a href="<?= SITE_URL ?>" class="btn-admin">🏠 На сайт</a>
        </div>

        <!-- Последняя активность -->
        <div class="recent-activity">
            <!-- Последние пользователи -->
            <div class="activity-card">
                <h3>Последние пользователи</h3>
                <ul class="activity-list">
                    <?php foreach ($latest_users as $user): ?>
                        <li class="activity-item">
                            <div class="user-info">
                                <div class="user-avatar"><?= strtoupper(substr($user['username'], 0, 1)) ?></div>
                                <div>
                                    <strong><?= htmlspecialchars($user['username']) ?></strong>
                                    <div style="font-size: 0.9em; color: #666;">
                                        <?= $user['role'] ?> • <?= date('d.m.Y', strtotime($user['created_at'])) ?>
                                    </div>
                                </div>
                            </div>
                            <a href="users.php?edit=<?= $user['id'] ?>" style="color: #3498db; text-decoration: none;">
                                Редактировать
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <!-- Последние рецепты -->
            <div class="activity-card">
                <h3>Последние рецепты</h3>
                <ul class="activity-list">
                    <?php foreach ($latest_recipes as $recipe): ?>
                        <li class="activity-item">
                            <div>
                                <strong><?= htmlspecialchars($recipe['title']) ?></strong>
                                <div style="font-size: 0.9em; color: #666;">
                                    Автор: <?= htmlspecialchars($recipe['username']) ?> • 
                                    <?= date('d.m.Y', strtotime($recipe['created_at'])) ?>
                                </div>
                            </div>
                            <a href="recipes.php?edit=<?= $recipe['id'] ?>" style="color: #3498db; text-decoration: none;">
                                Просмотр
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>

        <!-- Системная информация -->
        <div class="activity-card" style="margin-top: 30px;">
            <h3>Системная информация</h3>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
                <div>
                    <strong>PHP версия:</strong> <?= phpversion() ?>
                </div>
                <div>
                    <strong>MySQL версия:</strong> 
                    <?php 
                    $result = $db->query("SELECT VERSION() as version");
                    echo $result->fetch_assoc()['version'];
                    ?>
                </div>
                <div>
                    <strong>Сервер:</strong> <?= $_SERVER['SERVER_SOFTWARE'] ?>
                </div>
                <div>
                    <strong>Память:</strong> <?= round(memory_get_usage() / 1024 / 1024, 2) ?> MB
                </div>
            </div>
        </div>
    </div>
</body>
</html>