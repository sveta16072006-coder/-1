<?php
// Управление рецептами (админ-панель)
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/auth.php';

// Только для администраторов
requireAdmin();

// Подключаем базу данных
require_once __DIR__ . '/../../includes/database.php';

$db = Database::connect();
$page_title = "Управление рецептами";

// Обработка действий
$action = $_GET['action'] ?? '';
$recipe_id = $_GET['id'] ?? $_GET['edit'] ?? $_GET['delete'] ?? 0;

// Удаление рецепта
if (isset($_GET['delete']) && $recipe_id) {
    $stmt = $db->prepare("DELETE FROM recipes WHERE id = ?");
    $stmt->bind_param("i", $recipe_id);
    
    if ($stmt->execute()) {
        $success_message = "Рецепт успешно удален";
    } else {
        $error_message = "Ошибка при удалении рецепта";
    }
}

// Получение данных рецепта для редактирования
$current_recipe = null;
if ($recipe_id && ($action === 'edit' || isset($_GET['edit']))) {
    $stmt = $db->prepare("SELECT * FROM recipes WHERE id = ?");
    $stmt->bind_param("i", $recipe_id);
    $stmt->execute();
    $current_recipe = $stmt->get_result()->fetch_assoc();
}

// Сохранение рецепта
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'] ?? '';
    $description = $_POST['description'] ?? '';
    $ingredients = $_POST['ingredients'] ?? '';
    $instructions = $_POST['instructions'] ?? '';
    $cooking_time = $_POST['cooking_time'] ?? 0;
    $difficulty = $_POST['difficulty'] ?? 'medium';
    $category = $_POST['category'] ?? '';
    $user_id = $_POST['user_id'] ?? $_SESSION['user']['id'];
    
    if (empty($title) || empty($ingredients) || empty($instructions)) {
        $error_message = "Заполните обязательные поля: название, ингредиенты, инструкции";
    } else {
        if ($current_recipe) {
            // Обновление существующего рецепта
            $stmt = $db->prepare("UPDATE recipes SET title = ?, description = ?, ingredients = ?, instructions = ?, cooking_time = ?, difficulty = ?, category = ?, user_id = ? WHERE id = ?");
            $stmt->bind_param("ssssisssi", $title, $description, $ingredients, $instructions, $cooking_time, $difficulty, $category, $user_id, $recipe_id);
            $action_text = "обновлен";
        } else {
            // Создание нового рецепта
            $stmt = $db->prepare("INSERT INTO recipes (user_id, title, description, ingredients, instructions, cooking_time, difficulty, category) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("issssiss", $user_id, $title, $description, $ingredients, $instructions, $cooking_time, $difficulty, $category);
            $action_text = "добавлен";
            $recipe_id = $db->insert_id;
        }
        
        if ($stmt->execute()) {
            $success_message = "Рецепт успешно $action_text";
            
            // Если это было создание нового рецепта, получаем его данные
            if (!$current_recipe) {
                $stmt = $db->prepare("SELECT * FROM recipes WHERE id = ?");
                $stmt->bind_param("i", $recipe_id);
                $stmt->execute();
                $current_recipe = $stmt->get_result()->fetch_assoc();
            }
        } else {
            $error_message = "Ошибка при сохранении рецепта: " . $db->error;
        }
    }
}

// Получение списка всех рецептов
$search = $_GET['search'] ?? '';
$category_filter = $_GET['category'] ?? '';

$query = "SELECT r.*, u.username FROM recipes r JOIN users u ON r.user_id = u.id WHERE 1=1";
$params = [];
$types = "";

if ($search) {
    $query .= " AND (r.title LIKE ? OR r.description LIKE ?)";
    $search_param = "%$search%";
    $params[] = $search_param;
    $params[] = $search_param;
    $types .= "ss";
}

if ($category_filter) {
    $query .= " AND r.category = ?";
    $params[] = $category_filter;
    $types .= "s";
}

$query .= " ORDER BY r.created_at DESC";

$stmt = $db->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$recipes_result = $stmt->get_result();

// Получение всех категорий для фильтра
$categories_result = $db->query("SELECT DISTINCT category FROM recipes WHERE category IS NOT NULL AND category != '' ORDER BY category");

// Получение всех пользователей для выбора при создании рецепта
$users_result = $db->query("SELECT id, username FROM users ORDER BY username");
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Управление рецептами - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="<?= SITE_URL ?>assets/css/style.css">
    <style>
        .admin-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .admin-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 20px;
        }
        
        .filters {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: flex-end;
        }
        
        .filter-group {
            flex: 1;
            min-width: 200px;
        }
        
        .filter-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #2c3e50;
        }
        
        .recipes-table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .recipes-table th {
            background: #3498db;
            color: white;
            padding: 15px;
            text-align: left;
        }
        
        .recipes-table td {
            padding: 15px;
            border-bottom: 1px solid #eee;
        }
        
        .recipes-table tr:hover {
            background: #f9f9f9;
        }
        
        .recipe-actions {
            display: flex;
            gap: 10px;
        }
        
        .btn-edit {
            background: #2ecc71;
            color: white;
            padding: 5px 15px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 0.9em;
        }
        
        .btn-delete {
            background: #e74c3c;
            color: white;
            padding: 5px 15px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 0.9em;
        }
        
        .btn-view {
            background: #3498db;
            color: white;
            padding: 5px 15px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 0.9em;
        }
        
        .form-container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            max-width: 800px;
            margin: 0 auto;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #2c3e50;
        }
        
        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }
        
        .form-group textarea {
            min-height: 100px;
            resize: vertical;
        }
        
        .ingredients-textarea {
            font-family: monospace;
            min-height: 150px;
        }
        
        .instructions-textarea {
            min-height: 200px;
        }
        
        .form-actions {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }
        
        .btn-save {
            background: #2ecc71;
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        
        .btn-cancel {
            background: #95a5a6;
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
        }
        
        .difficulty-badge {
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 0.8em;
            font-weight: bold;
        }
        
        .difficulty-easy {
            background: #2ecc71;
            color: white;
        }
        
        .difficulty-medium {
            background: #f39c12;
            color: white;
        }
        
        .difficulty-hard {
            background: #e74c3c;
            color: white;
        }
        
        .empty-state {
            text-align: center;
            padding: 50px;
            color: #7f8c8d;
        }
        
        @media (max-width: 768px) {
            .recipes-table {
                display: block;
                overflow-x: auto;
            }
            
            .recipe-actions {
                flex-direction: column;
            }
            
            .admin-header {
                flex-direction: column;
                align-items: stretch;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <header class="admin-header">
            <div>
                <h1>Управление рецептами</h1>
                <nav>
                    <a href="index.php">← Админ-панель</a> | 
                    <a href="<?= SITE_URL ?>">На сайт</a> | 
                    <a href="<?= SITE_URL ?>pages/auth/logout.php">Выйти</a>
                </nav>
            </div>
            <div>
                <a href="?action=add" class="btn-save">➕ Добавить рецепт</a>
            </div>
        </header>

        <?php if (isset($success_message)): ?>
            <div style="background: #2ecc71; color: white; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
                ✅ <?= $success_message ?>
            </div>
        <?php endif; ?>

        <?php if (isset($error_message)): ?>
            <div style="background: #e74c3c; color: white; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
                ❌ <?= $error_message ?>
            </div>
        <?php endif; ?>

        <?php if ($action === 'add' || $action === 'edit'): ?>
            <!-- Форма добавления/редактирования рецепта -->
            <div class="form-container">
                <h2><?= $current_recipe ? 'Редактирование рецепта' : 'Добавление нового рецепта' ?></h2>
                
                <form method="POST" action="">
                    <div class="form-group">
                        <label for="title">Название рецепта *</label>
                        <input type="text" id="title" name="title" 
                               value="<?= htmlspecialchars($current_recipe['title'] ?? '') ?>" 
                               required>
                    </div>
                    
                    <div class="form-group">
                        <label for="description">Описание</label>
                        <textarea id="description" name="description"><?= htmlspecialchars($current_recipe['description'] ?? '') ?></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="ingredients">Ингредиенты * (каждый с новой строки)</label>
                        <textarea id="ingredients" name="ingredients" class="ingredients-textarea" required><?= htmlspecialchars($current_recipe['ingredients'] ?? '') ?></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="instructions">Инструкция приготовления *</label>
                        <textarea id="instructions" name="instructions" class="instructions-textarea" required><?= htmlspecialchars($current_recipe['instructions'] ?? '') ?></textarea>
                    </div>
                    
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px;">
                        <div class="form-group">
                            <label for="cooking_time">Время приготовления (минут)</label>
                            <input type="number" id="cooking_time" name="cooking_time" 
                                   value="<?= $current_recipe['cooking_time'] ?? 30 ?>" min="1">
                        </div>
                        
                        <div class="form-group">
                            <label for="difficulty">Сложность</label>
                            <select id="difficulty" name="difficulty">
                                <option value="easy" <?= ($current_recipe['difficulty'] ?? '') == 'easy' ? 'selected' : '' ?>>Легкая</option>
                                <option value="medium" <?= ($current_recipe['difficulty'] ?? 'medium') == 'medium' ? 'selected' : '' ?>>Средняя</option>
                                <option value="hard" <?= ($current_recipe['difficulty'] ?? '') == 'hard' ? 'selected' : '' ?>>Сложная</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="category">Категория</label>
                            <input type="text" id="category" name="category" list="categories"
                                   value="<?= htmlspecialchars($current_recipe['category'] ?? '') ?>">
                            <datalist id="categories">
                                <?php while ($cat = $categories_result->fetch_assoc()): ?>
                                    <option value="<?= htmlspecialchars($cat['category']) ?>">
                                <?php endwhile; ?>
                            </datalist>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="user_id">Автор рецепта</label>
                        <select id="user_id" name="user_id">
                            <?php while ($user = $users_result->fetch_assoc()): ?>
                                <option value="<?= $user['id'] ?>" 
                                    <?= ($current_recipe['user_id'] ?? $_SESSION['user']['id']) == $user['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($user['username']) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn-save">
                            <?= $current_recipe ? 'Сохранить изменения' : 'Добавить рецепт' ?>
                        </button>
                        <a href="recipes.php" class="btn-cancel">Отмена</a>
                    </div>
                </form>
            </div>
        <?php else: ?>
            <!-- Список рецептов -->
            <div class="filters">
                <div class="filter-group">
                    <label for="search">Поиск</label>
                    <input type="text" id="search" name="search" placeholder="Название или описание..." 
                           value="<?= htmlspecialchars($search) ?>">
                </div>
                
                <div class="filter-group">
                    <label for="category">Категория</label>
                    <select id="category" name="category">
                        <option value="">Все категории</option>
                        <?php 
                        $categories_result->data_seek(0); // Сброс указателя
                        while ($cat = $categories_result->fetch_assoc()): ?>
                            <option value="<?= htmlspecialchars($cat['category']) ?>" 
                                <?= $category_filter == $cat['category'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($cat['category']) ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                
                <div>
                    <button onclick="applyFilters()" class="btn-save">Применить</button>
                    <a href="recipes.php" class="btn-cancel">Сбросить</a>
                </div>
            </div>

            <?php if ($recipes_result->num_rows > 0): ?>
                <table class="recipes-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Название</th>
                            <th>Автор</th>
                            <th>Категория</th>
                            <th>Сложность</th>
                            <th>Время</th>
                            <th>Дата</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($recipe = $recipes_result->fetch_assoc()): ?>
                            <tr>
                                <td><?= $recipe['id'] ?></td>
                                <td>
                                    <strong><?= htmlspecialchars($recipe['title']) ?></strong>
                                    <?php if (!empty($recipe['description'])): ?>
                                        <div style="font-size: 0.9em; color: #666; margin-top: 5px;">
                                            <?= htmlspecialchars(substr($recipe['description'], 0, 100)) ?>...
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td><?= htmlspecialchars($recipe['username']) ?></td>
                                <td><?= htmlspecialchars($recipe['category'] ?? '-') ?></td>
                                <td>
                                    <span class="difficulty-badge difficulty-<?= $recipe['difficulty'] ?>">
                                        <?= $recipe['difficulty'] == 'easy' ? 'Легко' : 
                                              ($recipe['difficulty'] == 'medium' ? 'Средне' : 'Сложно') ?>
                                    </span>
                                </td>
                                <td><?= $recipe['cooking_time'] ?> мин</td>
                                <td><?= date('d.m.Y', strtotime($recipe['created_at'])) ?></td>
                                <td>
                                    <div class="recipe-actions">
                                        <a href="?edit=<?= $recipe['id'] ?>" class="btn-edit">✏️</a>
                                        <a href="<?= SITE_URL ?>pages/recipes/view.php?id=<?= $recipe['id'] ?>" 
                                           class="btn-view" target="_blank">👁️</a>
                                        <a href="?delete=<?= $recipe['id'] ?>" 
                                           class="btn-delete" 
                                           onclick="return confirm('Удалить рецепт «<?= htmlspecialchars($recipe['title']) ?>»?')">🗑️</a>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="empty-state">
                    <h3>Рецептов не найдено</h3>
                    <p>Попробуйте изменить параметры поиска или добавьте первый рецепт</p>
                    <a href="?action=add" class="btn-save" style="margin-top: 20px;">➕ Добавить рецепт</a>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>

    <script>
        function applyFilters() {
            const search = document.getElementById('search').value;
            const category = document.getElementById('category').value;
            
            let url = 'recipes.php?';
            if (search) url += 'search=' + encodeURIComponent(search) + '&';
            if (category) url += 'category=' + encodeURIComponent(category);
            
            window.location.href = url;
        }
        
        // Автоприменение фильтров при изменении
        document.getElementById('search').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') applyFilters();
        });
        
        document.getElementById('category').addEventListener('change', applyFilters);
    </script>
</body>
</html>