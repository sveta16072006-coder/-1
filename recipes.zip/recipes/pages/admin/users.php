<?php
require_once '../../includes/config.php';
require_once '../../includes/database.php';

// Проверка прав администратора
if (!isAdmin()) {
    redirect('');
}

// Обработка удаления пользователя
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    if ($id != $_SESSION['user']['id']) { // Нельзя удалить себя
        $db = Database::connect();
        $stmt = $db->prepare("DELETE FROM users WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
    }
    redirect('pages/admin/users.php');
}

$users = getAllUsers();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Управление пользователями - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="<?= SITE_URL ?>assets/css/style.css">
    <style>
        .admin-container { max-width: 1200px; margin: 0 auto; }
        .users-table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        .users-table th, .users-table td { padding: 10px; border: 1px solid #ddd; text-align: left; }
        .users-table th { background: #3498db; color: white; }
        .btn-edit { background: #2ecc71; color: white; padding: 5px 10px; text-decoration: none; }
        .btn-delete { background: #e74c3c; color: white; padding: 5px 10px; text-decoration: none; }
    </style>
</head>
<body>
    <div class="admin-container">
        <header>
            <h1>Управление пользователями</h1>
            <nav>
                <a href="<?= SITE_URL ?>">Главная</a>
                <a href="<?= SITE_URL ?>pages/admin/">Админпанель</a>
                <a href="<?= SITE_URL ?>pages/auth/logout.php">Выйти</a>
            </nav>
        </header>

        <table class="users-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Логин</th>
                    <th>Email</th>
                    <th>Имя</th>
                    <th>Роль</th>
                    <th>Дата регистрации</th>
                    <th>Действия</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?= $user['id'] ?></td>
                        <td><?= escape($user['username']) ?></td>
                        <td><?= escape($user['email']) ?></td>
                        <td><?= escape($user['full_name']) ?></td>
                        <td><?= $user['role'] ?></td>
                        <td><?= $user['created_at'] ?></td>
                        <td>
                            <a href="?edit=<?= $user['id'] ?>" class="btn-edit">Изменить</a>
                            <?php if ($user['id'] != $_SESSION['user']['id']): ?>
                                <a href="?delete=<?= $user['id'] ?>" class="btn-delete" onclick="return confirm('Удалить пользователя?')">Удалить</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>