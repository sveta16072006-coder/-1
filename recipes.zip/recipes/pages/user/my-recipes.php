<?php
// Мои рецепты (личный кабинет)
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/auth.php';

// Только для авторизованных пользователей
requireLogin();

// Подключаем базу данных
require_once __DIR__ . '/../../includes/database.php';

$db = Database::connect();
$user = getCurrentUser();
$user_id = $user['id'];
$page_title = "Мои рецепты";

// Обработка удаления рецепта
if (isset($_GET['delete'])) {
    $recipe_id = (int)$_GET['delete'];
    
    // Проверяем, принадлежит ли рецепт пользователю
    $stmt = $db->prepare("SELECT user_id FROM recipes WHERE id = ?");
    $stmt->bind_param("i", $recipe_id);
    $stmt->execute();
    $recipe = $stmt->get_result()->fetch_assoc();
    
    if ($recipe && canEditRecipe($recipe['user_id'])) {
        $stmt = $db->prepare("DELETE FROM recipes WHERE id = ?");
        $stmt->bind_param("i", $recipe_id);
        
        if ($stmt->execute()) {
            $success_message = "Рецепт успешно удален";
        } else {
            $error_message = "Ошибка при удалении рецепта";
        }
    } else {
        $error_message = "У вас нет прав для удаления этого рецепта";
    }
}

// Получение рецептов пользователя
$search = $_GET['search'] ?? '';
$category_filter = $_GET['category'] ?? '';

$query = "SELECT * FROM recipes WHERE user_id = ?";
$params = [$user_id];
$types = "i";

if ($search) {
    $query .= " AND (title LIKE ? OR description LIKE ?)";
    $search_param = "%$search%";
    $params[] = $search_param;
    $params[] = $search_param;
    $types .= "ss";
}

if ($category_filter) {
    $query .= " AND category = ?";
    $params[] = $category_filter;
    $types .= "s";
}

$query .= " ORDER BY created_at DESC";

$stmt = $db->prepare($query);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$recipes_result = $stmt->get_result();

// Получение категорий пользователя
$categories_stmt = $db->prepare("SELECT DISTINCT category FROM recipes WHERE user_id = ? AND category IS NOT NULL AND category != '' ORDER BY category");
$categories_stmt->bind_param("i", $user_id);
$categories_stmt->execute();
$categories_result = $categories_stmt->get_result();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Мои рецепты - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="<?= SITE_URL ?>assets/css/style.css">
    <style>
        .my-recipes-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 20px;
        }
        
        .filters {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: flex-end;
        }
        
        .filter-group {
            flex: 1;
            min-width: 200px;
        }
        
        .recipes-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 25px;
        }
        
        .recipe-card {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            transition: transform 0.3s, box-shadow 0.3s;
        }
        
        .recipe-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.15);
        }
        
        .recipe-image {
            height: 180px;
            background: linear-gradient(135deg, #3498db, #2ecc71);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 3em;
        }
        
        .recipe-content {
            padding: 20px;
        }
        
        .recipe-title {
            margin: 0 0 10px 0;
            color: #2c3e50;
            font-size: 1.3em;
        }
        
        .recipe-description {
            color: #666;
            margin-bottom: 15px;
            line-height: 1.5;
        }
        
        .recipe-meta {
            display: flex;
            justify-content: space-between;
            color: #7f8c8d;
            font-size: 0.9em;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid #eee;
        }
        
        .recipe-actions {
            display: flex;
            gap: 10px;
        }
        
        .btn-view {
            flex: 1;
            background: #3498db;
            color: white;
            padding: 8px;
            text-align: center;
            text-decoration: none;
            border-radius: 5px;
        }
        
        .btn-edit {
            flex: 1;
            background: #2ecc71;
            color: white;
            padding: 8px;
            text-align: center;
            text-decoration: none;
            border-radius: 5px;
        }
        
        .btn-delete {
            flex: 1;
            background: #e74c3c;
            color: white;
            padding: 8px;
            text-align: center;
            text-decoration: none;
            border-radius: 5px;
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-top: 30px;
        }
        
        .empty-state-icon {
            font-size: 4em;
            margin-bottom: 20px;
            color: #bdc3c7;
        }
        
        .difficulty-badge {
            display: inline-block;
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 0.8em;
            font-weight: bold;
            margin-top: 5px;
        }
        
        .difficulty-easy { background: #2ecc71; color: white; }
        .difficulty-medium { background: #f39c12; color: white; }
        .difficulty-hard { background: #e74c3c; color: white; }
        
        .pagination {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-top: 40px;
        }
        
        .pagination a,
        .pagination span {
            padding: 8px 15px;
            background: white;
            border: 1px solid #ddd;
            border-radius: 5px;
            text-decoration: none;
            color: #3498db;
        }
        
        .pagination .active {
            background: #3498db;
            color: white;
            border-color: #3498db;
        }
        
        @media (max-width: 768px) {
            .recipes-grid {
                grid-template-columns: 1fr;
            }
            
            .page-header {
                flex-direction: column;
                align-items: stretch;
            }
            
            .filters {
                flex-direction: column;
            }
            
            .filter-group {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="my-recipes-container">
        <!-- Заголовок -->
        <div class="page-header">
            <div>
                <h1>Мои рецепты</h1>
                <nav>
                    <a href="<?= SITE_URL ?>">← На главную</a> | 
                    <a href="profile.php">👤 Мой профиль</a> | 
                    <a href="<?= SITE_URL ?>pages/auth/logout.php">Выйти</a>
                </nav>
            </div>
            <div>
                <a href="<?= SITE_URL ?>pages/recipes/?action=add" class="btn-save" style="background: #2ecc71; color: white; padding: 12px 25px; text-decoration: none; border-radius: 5px;">
                    ➕ Добавить рецепт
                </a>
            </div>
        </div>

        <!-- Сообщения -->
        <?php if (isset($success_message)): ?>
            <div style="background: #2ecc71; color: white; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
                ✅ <?= $success_message ?>
            </div>
        <?php endif; ?>

        <?php if (isset($error_message)): ?>
            <div style="background: #e74c3c; color: white; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
                ❌ <?= $error_message ?>
            </div>
        <?php endif; ?>

        <!-- Фильтры -->
        <div class="filters">
            <div class="filter-group">
                <label for="search">Поиск по рецептам</label>
                <input type="text" id="search" name="search" placeholder="Название или описание..." 
                       value="<?= htmlspecialchars($search) ?>">
            </div>
            
            <div class="filter-group">
                <label for="category">Категория</label>
                <select id="category" name="category">
                    <option value="">Все категории</option>
                    <?php while ($cat = $categories_result->fetch_assoc()): ?>
                        <option value="<?= htmlspecialchars($cat['category']) ?>" 
                            <?= $category_filter == $cat['category'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($cat['category']) ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            
            <div>
                <button onclick="applyFilters()" style="background: #3498db; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer;">
                    Применить
                </button>
                <a href="my-recipes.php" style="background: #95a5a6; color: white; padding: 10px 20px; border-radius: 5px; text-decoration: none; display: inline-block;">
                    Сбросить
                </a>
            </div>
        </div>

        <!-- Список рецептов -->
        <?php if ($recipes_result->num_rows > 0): ?>
            <div class="recipes-grid">
                <?php while ($recipe = $recipes_result->fetch_assoc()): ?>
                    <div class="recipe-card">
                        <div class="recipe-image">
                            <?= strtoupper(substr($recipe['title'], 0, 1)) ?>
                        </div>
                        <div class="recipe-content">
                            <h3 class="recipe-title"><?= htmlspecialchars($recipe['title']) ?></h3>
                            
                            <?php if (!empty($recipe['description'])): ?>
                                <p class="recipe-description">
                                    <?= htmlspecialchars(substr($recipe['description'], 0, 150)) ?>
                                    <?= strlen($recipe['description']) > 150 ? '...' : '' ?>
                                </p>
                            <?php endif; ?>
                            
                            <div class="recipe-meta">
                                <div>
                                    <div>⏱️ <?= $recipe['cooking_time'] ?> мин</div>
                                    <span class="difficulty-badge difficulty-<?= $recipe['difficulty'] ?>">
                                        <?= $recipe['difficulty'] == 'easy' ? 'Легко' : 
                                              ($recipe['difficulty'] == 'medium' ? 'Средне' : 'Сложно') ?>
                                    </span>
                                </div>
                                <div>
                                    <div>👁️ <?= $recipe['views'] ?></div>
                                    <div style="font-size: 0.8em; margin-top: 5px;">
                                        <?= date('d.m.Y', strtotime($recipe['created_at'])) ?>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="recipe-actions">
                                <a href="<?= SITE_URL ?>pages/recipes/view.php?id=<?= $recipe['id'] ?>" class="btn-view">
                                    Просмотр
                                </a>
                                <a href="<?= SITE_URL ?>pages/recipes/?edit=<?= $recipe['id'] ?>" class="btn-edit">
                                    Редактировать
                                </a>
                                <a href="?delete=<?= $recipe['id'] ?>" class="btn-delete" 
                                   onclick="return confirm('Удалить рецепт «<?= htmlspecialchars(addslashes($recipe['title'])) ?>»?')">
                                    Удалить
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <div class="empty-state-icon">🍳</div>
                <h2>Рецептов не найдено</h2>
                <p style="color: #666; margin: 15px 0;">
                    <?php if ($search || $category_filter): ?>
                        Попробуйте изменить параметры поиска
                    <?php else: ?>
                        У вас пока нет созданных рецептов
                    <?php endif; ?>
                </p>
                <a href="<?= SITE_URL ?>pages/recipes/?action=add" style="background: #2ecc71; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block; margin-top: 15px;">
                    ➕ Создать первый рецепт
                </a>
            </div>
        <?php endif; ?>
        
        <!-- Количество рецептов -->
        <div style="text-align: center; margin-top: 40px; color: #666; padding: 20px; background: white; border-radius: 10px;">
            Всего рецептов: <strong><?= $recipes_result->num_rows ?></strong>
        </div>
    </div>

    <script>
        function applyFilters() {
            const search = document.getElementById('search').value;
            const category = document.getElementById('category').value;
            
            let url = 'my-recipes.php?';
            if (search) url += 'search=' + encodeURIComponent(search) + '&';
            if (category) url += 'category=' + encodeURIComponent(category);
            
            window.location.href = url;
        }
        
        // Автоприменение фильтров при изменении
        document.getElementById('search').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') applyFilters();
        });
        
        document.getElementById('category').addEventListener('change', applyFilters);
    </script>
</body>
</html>