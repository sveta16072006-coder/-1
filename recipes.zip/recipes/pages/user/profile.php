<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/auth.php';
requireLogin();

$user = $_SESSION['user'];
?>
<!DOCTYPE html>
<html>
<head>
    <title>Профиль - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="<?= SITE_URL ?>assets/css/style.css">
</head>
<body>
    <div style="max-width: 800px; margin: 0 auto; padding: 20px;">
        <h1>Мой профиль</h1>
        <p><strong>Имя:</strong> <?= escape($user['username']) ?></p>
        <p><strong>Email:</strong> <?= escape($user['email']) ?></p>
        <p><strong>Роль:</strong> <?= $user['role'] ?></p>
        <a href="<?= SITE_URL ?>">На главную</a> | 
        <a href="logout.php">Выйти</a>
    </div>
</body>
</html>