<?php
// login.php - страница входа
require_once '../../includes/config.php'; // ← ИСПРАВЛЕНО путь

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if ($username === 'admin' && $password === '123456') {
        $_SESSION['user'] = ['username' => 'admin', 'role' => 'admin'];
        header('Location: ../../index.php'); // ← ИСПРАВЛЕНО путь
        exit();
    } else {
        $error = "Неверные данные!";
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Вход - Кулинарные рецепты</title>
    <link rel="stylesheet" href="../../assets/css/style.css"> <!-- ← ИСПРАВЛЕНО -->
    <style>
        /* стили остаются те же */
    </style>
</head>
<body>
    <!-- остальной код -->
</body>
</html>