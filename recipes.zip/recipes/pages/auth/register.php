<?php
// register.php - страница регистрации
require_once '../../includes/config.php'; // ← ИСПРАВЛЕНО
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Регистрация - Кулинарные рецепты</title>
    <link rel="stylesheet" href="../../assets/css/style.css"> <!-- ← ИСПРАВЛЕНО -->
    <style>
        /* стили остаются */
    </style>
</head>
<body>
    <!-- остальной код -->
</body>
</html>