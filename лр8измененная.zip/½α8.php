<?php
session_start();

if (isset($_POST['month']) || isset($_POST['year'])) {
    $_SESSION['calendar_month'] = $_POST['month'] ?? $_SESSION['calendar_month'] ?? date('n');
    $_SESSION['calendar_year'] = $_POST['year'] ?? $_SESSION['calendar_year'] ?? date('Y');
    header("Location: " . $_SERVER['PHP_SELF'] . "?tab=2");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
    $errors = [];
    $fullname = trim($_POST['fullname'] ?? '');
    $login = trim($_POST['login'] ?? '');
    $password = $_POST['password'] ?? '';
    $birthdate = $_POST['birthdate'] ?? '';

    if (empty($fullname) || strlen($fullname) < 5) $errors[] = "ФИО: минимум 5 символов";
    if (empty($login) || strlen($login) < 3) $errors[] = "Логин: минимум 3 символа";
    if (empty($password) || strlen($password) < 6) $errors[] = "Пароль: минимум 6 символов";
    if (empty($birthdate)) $errors[] = "Укажите дату рождения";

    if (empty($errors)) {
        $_SESSION['show_success_popup'] = true;
        header("Location: " . $_SERVER['PHP_SELF'] . "?tab=3");
        exit;
    } else {
        $_SESSION['active_tab'] = 3;
    }
}

$showSuccessPopup = isset($_SESSION['show_success_popup']) && $_SESSION['show_success_popup'];
if ($showSuccessPopup) {
    unset($_SESSION['show_success_popup']);
}

$active_tab = $_SESSION['active_tab'] ?? 1;
$month = $_SESSION['calendar_month'] ?? date('n');
$year = $_SESSION['calendar_year'] ?? date('Y');
?>

<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Задания</title>
    <style>
        body {
            background: #ffb6c1;
            padding: 20px;
            font-family: Arial, sans-serif;
        }

        .container {
            max-width: 1000px;
            margin: 0 auto;
        }

        .header {
            text-align: center;
            margin-bottom: 20px;
            padding: 20px;
            background: white;
            border-radius: 10px;
        }

        .header h1 {
            color: #ff1493;
            margin-bottom: 10px;
        }

        .header p {
            color: #ff69b4;
        }

        .buttons {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            justify-content: center;
        }

        .buttons button {
            padding: 10px 20px;
            background: #ff69b4;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .content {
            background: white;
            padding: 20px;
            border-radius: 10px;
        }

        .task {
            display: none;
        }

        .task.active {
            display: block;
        }

        h2 {
            color: #ff1493;
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            border-collapse: collapse;
            margin: 0 auto;
        }

        th, td {
            border: 1px solid #ff69b4;
            padding: 8px;
            text-align: center;
        }

        th {
            background: #ff69b4;
            color: white;
        }

        .calendar-form {
            margin-bottom: 20px;
            text-align: center;
        }

        .calendar-form select {
            padding: 5px;
            margin: 0 5px;
        }

        .calendar table {
            margin: 20px auto;
        }

        .calendar td {
            padding: 10px;
        }

        .calendar .weekend {
            background: #ffe4ec;
        }

        .calendar .holiday {
            background: #ffcccc;
            color: red;
            font-weight: bold;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #ff1493;
            font-weight: bold;
        }

        .form-group input {
            width: 100%;
            max-width: 300px;
            padding: 8px;
            border: 1px solid #ffb6c1;
            border-radius: 5px;
        }

        button.submit {
            background: #ff69b4;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            display: block;
            margin: 20px auto;
        }

        .error {
            color: red;
            background: #ffe6e6;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
        }

        .success-popup {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #ff69b4;
            color: white;
            padding: 15px 25px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(255, 105, 180, 0.3);
            z-index: 1000;
            animation: fadeIn 0.5s, fadeOut 0.5s 2.5s;
            font-weight: bold;
            border: 2px solid #ff1493;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateX(50px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        @keyframes fadeOut {
            from {
                opacity: 1;
            }
            to {
                opacity: 0;
            }
        }
    </style>
</head>
<body>

<?php if ($showSuccessPopup): ?>
    <div class="success-popup">Спасибо за регистрацию!</div>
<?php endif; ?>

<div class="container">
    <div class="header">
        <h1>Лабораторная 8. PHP задания</h1>
        <p>Выберите задание для просмотра</p>
    </div>

    <div class="buttons">
        <button onclick="showTask(1)">Таблица умножения</button>
        <button onclick="showTask(2)">Календарь</button>
        <button onclick="showTask(3)">Регистрация</button>
    </div>

    <div class="content">
        <div id="task1" class="task <?php echo $active_tab == 1 ? 'active' : ''; ?>">
            <h2>Таблица умножения от 1 до 10</h2>
            <table>
                <tr>
                    <th>×</th>
                    <?php for ($i = 1; $i <= 10; $i++) echo "<th>$i</th>"; ?>
                </tr>
                <?php for ($i = 1; $i <= 10; $i++) {
                    echo "<tr><th>$i</th>";
                    for ($j = 1; $j <= 10; $j++) echo "<td>" . ($i * $j) . "</td>";
                    echo "</tr>";
                } ?>
            </table>
        </div>

        <div id="task2" class="task <?php echo $active_tab == 2 ? 'active' : ''; ?>">
            <h2>Календарь на месяц</h2>
            <div class="calendar-form">
                <form method="POST" id="calendarForm">
                    <select name="month" onchange="this.form.submit()">
                        <?php
                        $months = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'];
                        foreach ($months as $k => $v) {
                            $selected = ($month == $k + 1) ? ' selected' : '';
                            echo "<option value='" . ($k + 1) . "'$selected>$v</option>";
                        }
                        ?>
                    </select>
                    <select name="year" onchange="this.form.submit()">
                        <?php
                        for ($y = 2020; $y <= 2030; $y++) {
                            $selected = ($year == $y) ? ' selected' : '';
                            echo "<option$selected>$y</option>";
                        }
                        ?>
                    </select>
                </form>
            </div>
            <div class="calendar">
                <?php
                $days = date('t', mktime(0, 0, 0, $month, 1, $year));
                $firstDay = date('w', mktime(0, 0, 0, $month, 1, $year));
                $firstDay = $firstDay == 0 ? 6 : $firstDay - 1;
                $holidays = [
                    '1-1' => 'Новый год',
                    '1-7' => 'Рождество Христово',
                    '2-23' => 'День защитника Отечества',
                    '3-8' => 'Международный женский день',
                    '5-1' => 'День весны и труда',
                    '5-9' => 'День Победы',
                    '6-12' => 'День России',
                    '11-4' => 'День народного единства'
                ];
                echo "<table><tr><th>Пн</th><th>Вт</th><th>Ср</th><th>Чт</th><th>Пт</th><th>Сб</th><th>Вс</th></tr><tr>";
                for ($i = 0; $i < $firstDay; $i++) echo "<td></td>";
                for ($day = 1; $day <= $days; $day++) {
                    $class = '';
                    $dayOfWeek = ($firstDay + $day - 1) % 7;
                    $holidayKey = "$month-$day";
                    $isHoliday = isset($holidays[$holidayKey]);
                    if ($dayOfWeek == 5 || $dayOfWeek == 6) $class = 'weekend';
                    if ($isHoliday) $class = 'holiday';
                    echo "<td class='$class' title='" . ($isHoliday ? $holidays[$holidayKey] : '') . "'>$day</td>";
                    if (($firstDay + $day) % 7 == 0 && $day != $days) echo "</tr><tr>";
                }
                echo "</tr></table>";
                ?>
            </div>
        </div>

        <div id="task3" class="task <?php echo $active_tab == 3 ? 'active' : ''; ?>">
            <h2>Регистрация пользователя</h2>
            <form method="POST">
                <?php if (!empty($errors)): ?>
                    <div class="error"><?php foreach ($errors as $e) echo "<div>$e</div>"; ?></div>
                <?php endif; ?>
                <div class="form-group">
                    <label>ФИО:</label>
                    <input type="text" name="fullname" required>
                </div>
                <div class="form-group">
                    <label>Логин:</label>
                    <input type="text" name="login" required>
                </div>
                <div class="form-group">
                    <label>Пароль:</label>
                    <input type="password" name="password" required>
                </div>
                <div class="form-group">
                    <label>Дата рождения:</label>
                    <input type="date" name="birthdate" required>
                </div>
                <button type="submit" name="register" class="submit">Зарегистрироваться</button>
            </form>
        </div>
    </div>
</div>

<script>
    function showTask(n) {
        window.location.href = '?tab=' + n;
    }

    setTimeout(() => {
        const popup = document.querySelector('.success-popup');
        if (popup) popup.style.display = 'none';
    }, 3000);
</script>

</body>
</html>
